This directory contains a bunch of simple programs to test various properties of
the virtual (non TDE) disk image access.
