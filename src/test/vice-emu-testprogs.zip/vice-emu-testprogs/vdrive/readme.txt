This directory contains various programs for testing the behaviour of the virtual
(non TDE) devices.
