test1.prg:

simple two-way transfer with strings.

TODO: apparently only sending works correctly, no data is being recieved.

