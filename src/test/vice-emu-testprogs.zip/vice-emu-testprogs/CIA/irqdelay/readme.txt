various tests that detect the CIA type(s) by the 1-cylce IRQ delay difference.

green border shows success (detected CIA type must match aswell, ofcourse)
