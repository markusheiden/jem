collection of simple nmi related tests:

main.s - check if basic handling of restore key works
main2.s - check if restore key presses are randomly distributed across a frame

