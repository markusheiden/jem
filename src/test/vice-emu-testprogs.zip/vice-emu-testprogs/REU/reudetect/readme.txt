this is a simple REU detection, taken from the demo "BlueREU".

red border - failed (no REU)
yellow border - REU was detected, but data test failed
green - ok (the blu.reu file from said demo must be loaded)
