
colorram.prg:
-------------

checks REU->C64 transfer when the target is colorram

- press SPACE to hold the time/rasterline when the transfer is started
- when the test passes the border shows green
