this program simply shows a (koala) picture in multicolor mode. this
picture shows the c64 colors, and demonstrates the mix colors which
are created by the pal en/decoding process.
