paltest: demonstrates the mix colors created by pal en/decoding.

emusux0r-crest: demonstrates the "black bleeding" effect created by the nmos
output stages.
