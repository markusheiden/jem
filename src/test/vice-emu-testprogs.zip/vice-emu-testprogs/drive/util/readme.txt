some simple (PC) tools to generate test data. 
