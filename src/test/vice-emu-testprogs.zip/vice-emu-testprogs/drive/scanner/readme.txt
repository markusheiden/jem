
scan35.d64, scan40.d64, scan42.d64
scan35.g64, scan40.g64, scan42.g64


scan35err.d64, scan40err.d64, scan42err.d64

the same scanner, but with disk errors in the error map of the D64. some older
original games used this for protection, for example: space taxi, platoon (pal), 
typhoon (pal), combat school (pal)

