diskid1.prg

checks the disk id of the sector headers (of track 18) and compares them with
the disk id of the directory (in the D64)

TODO: actually read the ID from track 18.0 and not use the hardcoded value