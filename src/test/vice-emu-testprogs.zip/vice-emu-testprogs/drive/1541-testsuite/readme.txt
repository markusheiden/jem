taken from http://developer.berlios.de/projects/rrtools/

TODO:
    - pc64-ANEB test uses hardcoded $ee mask and thus will randomly fail on some
      CPUs / drives
    - pc64-LXAB test uses hardcoded $ee mask and thus will randomly fail on some
      CPUs / drives

