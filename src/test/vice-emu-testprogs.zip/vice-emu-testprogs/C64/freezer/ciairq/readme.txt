This test can be used to verify that a freezer restores active CIA timer
interrupts correctly. Run the respective test, freeze and restart - only the
previously running interrupts should be active (indicated by the incrementing
characters in top left corner of the screen)

ciairq1t1.prg - CIA1 Timer1 is running
ciairq1t2.prg - CIA1 Timer2 is running
ciairq2t1.prg - CIA2 Timer1 is running
ciairq2t2.prg - CIA2 Timer2 is running
