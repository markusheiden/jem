this simple program simply shows the raster counter, start it using autostart
to verify the autostart delay is actually randomly spread over one frame.
