The programs in this directory can be used to verify that a program started by
whatever means finds an environment that resembles being loaded using kernal
after a clean reset. This is important in all kinds of "autostart" scenarios,
because many, technically broken, programs exist that will not work properly
(or at all) otherwise.
