
some small basic programs that print a few important pointer values
