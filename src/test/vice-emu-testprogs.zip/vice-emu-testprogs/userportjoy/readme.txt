The testjoy.c file is a universal source file, it compiles with the cc65 
compiler package and can produce c128, c64(dtv), cbm510, cbm610, pet, 
plus4 and vic20 binaries (which are included in this directory).

