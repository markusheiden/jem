test1.prg:
- simple stable raster sync using lightpen trigger. 
  color bars at the top must be stable and line up with the color bars below

test2.prg:
- measures lightpen trigger delay (upper left)
