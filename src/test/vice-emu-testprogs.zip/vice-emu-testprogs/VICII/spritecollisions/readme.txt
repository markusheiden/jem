sprite-gfx-collision-cycle.prg:
CCBBBBB    (C64, C64C)
CBBBBBB    (DTV)

sprite-sprite-collision-cycle.prg:
CC@@@@@    (C64, C64C)
C@@@@@@    (DTV)

sprite-sprite.prg: (C64, C64C)
---------@-
---------@-

sprite-sprite.prg: (DTV)
@@--@--@-@-
---------@-

TODO:
- automatically generate DTV versions as well
- verify and fix NTSC versions
