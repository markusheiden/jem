Readme for spritescan
---------------------

-----------------------------------------------------------------------

dump6569.bin
------------
Dumped on Machine 1 (tlr):

C64: PAL Breadbox
Ser# U.K.B 1521345

CPU:  MOS/6510 CBM/3184
CIA1: MOS/6526/3884
CIA2: MOS/6526 R4/3283
VICII: 6569R3 (guess)
SID: <unknown>

dump6572.bin
------------
Dumped on Machine 1 (hedning):

Drean C64C (SC-136712), rev a-motherboard from 1982 (assy: 326298).
CPU: MOS/6510/0683
CIA1: <unknown>
CIA2: <unknown>
VICII: 6572R1 (guess)
SID: MOS/6581/5182 


dump8565.bin
------------
Dumped on Machine 1 (hedning):

C64C (HB5247478E), rev B 1992, Assy: 254069

CPU: CSG/8500/2292 24
CIA1: CSG/6526A/2592 216A
CIA2: CSG/6526A/2592 216A
VICII: CSG/8565R2/2092
SID: CSG/8580R5/2392 25

note: this one is equal to dump6569.bin

-----------------------------------------------------------------------
eof
