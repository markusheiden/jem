
This test creates a split in the X-expansion register and moves a sprite over
it, see bug #445
