
6502 instruction set test

taken from http://code.google.com/p/hmc-6502/

ported to ACME syntax and made to work on C64, green border shows success. in
case of failure red border is shown and $0400 contains number of failed test.

-------------------------------------------------------------------------------
