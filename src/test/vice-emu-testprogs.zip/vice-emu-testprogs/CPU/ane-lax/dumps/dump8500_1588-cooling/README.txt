cpu*: CPU cooled (using cooling spray)
vic*: VIC cooled (using cooling spray)

system was just turned on for each test run, kept off for ~30-60min between
cpu and vic tests

???before: baseline before cooling
???cool  : cooling started approx. 10 seconds before starting test,
           continued until test complete but before saving
???after1: ran immediately after ???cool test
???after2: roughly 1-2 minutes after 1
???after3: "some time later" (10-15 minutes probably, not timed)
