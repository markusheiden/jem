[18:07]	Unseen2: Another variable: Power suppy
[18:08]	Unseen2: 1764* is the modified C128 supply that came with the 1764, c64c* a standard C64C brick. Box was off for ~15min between the tests
[18:10]	Unseen2: 5.03V for the c64c brick, 4.95-4.96 (for the 1764
[18:12]	Unseen2: I need to change the caps on the 1764's supply some day, in theory it's the better one because it doesn't have the overvoltage-failure-mode, but currently it's emitting a quiet but annoying squeal while the C64 is on
