
This test can be used to check if the JAM opcode(s) actually do what they are
supposed to do (halt the CPU).

TODO: program timer nmi and irq to trigger during JAM
