this directory contains various programs that test the CPU itself.

If not stated otherwise, all programs run on the C-64 (and thus test the NMOS6510)

see also http://visual6502.org/wiki/index.php?title=6502TestPrograms
 
