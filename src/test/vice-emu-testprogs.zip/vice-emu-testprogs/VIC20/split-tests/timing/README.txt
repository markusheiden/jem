Readme for timing
-----------------

-----------------------------------------------------------------------

dumps/dump6560.prg (timing-r01c.prg, hardcoded NTSC timing) 
-------------------
Dumped on machine (vicassembly): 

VIC-20: NTSC

dumps/dump6560-101.prg (timing-r01c.prg, hardcoded NTSC timing) 
-------------------
Dumped on machine (wilson): 

VIC-20: CR (NTSC)
Serial: P1026787

CPU: MOS/6502 A/4682
VIA1: MOS/6522/5082
VIA2: MOS/6522/5082
VIC: MOS/6560-101/4982 


dumps/dump6561e.prg
-------------------
Dumped on machine (tlr): 

VIC-20: Two-prong breadbox (PAL)
Serial: WG C 10316
Assy.No: 324003  (sticker: 083171)
  KU-14IT94HB

CPU: MOS/MPS 6502/4381
VIA1: MOS/MPS 6522/4881
VIA2: MOS/MPS 6522/4881
VIC: MOS/6561E/4881

---
Matches machine (Mike):

VIC-20: CR (PAL), VFLI mod
Serial: WG A 93827

CPU: MOS/6502 B/1883
VIA1: MOS/6522/0983
VIA2: MOS/6522/0983
VIC: MOS/6561-101/2583


dumps/dump6561-101.prg
----------------------
Dumped on machine (tlr): 

VIC-20: CR (PAL)
Serial: WG C 139324

CPU: MOS/6502 A/3483
VIA1: MOS/6522/3283
VIA2: MOS/6522/3283
VIC: MOS/6561-101/3583


-----------------------------------------------------------------------
eof
