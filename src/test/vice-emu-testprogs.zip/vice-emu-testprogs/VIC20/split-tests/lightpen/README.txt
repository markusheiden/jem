Readme for lightpen
-------------------

-----------------------------------------------------------------------

dumps/dump6560.prg
------------------
Dumped on machine (wilson): 

VIC-20: CR (NTSC)
Serial: P1026787

CPU: MOS/6502 A/4682
VIA1: MOS/6522/5082
VIA2: MOS/6522/5082
VIC: MOS/6560-101/4982 

dumps/dump6561e.prg
-------------------
Dumped on machine (tlr): 
(later verified with an additional 3 successive dumps)

VIC-20: Two-prong breadbox (PAL)
Serial: WG C 10316
Assy.No: 324003  (sticker: 083171)
  KU-14IT94HB

CPU: MOS/MPS 6502/4381
VIA1: MOS/MPS 6522/4881
VIA2: MOS/MPS 6522/4881
VIC: MOS/6561E/4881

---
Matches machine (tlr):
(verified with 3 successive dumps)

VIC-20: CR (PAL)
Serial: WG C 139324

CPU: MOS/6502 A/3483
VIA1: MOS/6522/3283
VIA2: MOS/6522/3283
VIC: MOS/6561-101/3583

---
Matches machine (Mike):

VIC-20: CR (PAL), VFLI mod
Serial: WG A 93827

CPU: MOS/6502 B/1883
VIA1: MOS/6522/0983
VIA2: MOS/6522/0983
VIC: MOS/6561-101/2583


-----------------------------------------------------------------------
eof
