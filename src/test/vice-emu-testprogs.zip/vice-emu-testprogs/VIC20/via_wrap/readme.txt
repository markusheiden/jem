xvic -default -memory 2 via_wrap2.prg
