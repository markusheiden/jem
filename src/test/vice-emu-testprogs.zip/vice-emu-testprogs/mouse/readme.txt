simple mouse driver test program. expects mouse in port 1 
