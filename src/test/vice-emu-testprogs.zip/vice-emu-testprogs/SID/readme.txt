
this dir contains some programs that check various properties of the SID chip

--------------------------------------------------------------------------------

some info:

http://ftp.giga.or.at/pub/c64/library/sidnoise.txt (Uncovering the waveforms of the SID)
http://www.sid.fi/sidwiki/doku.php?id=sid-knowledge (Collection of thoughts by Mixer)
http://www.dekadence64.org/sidwav.txt (NEW WAVEFORMS w/ NOISE)
http://csdb.dk/forums/?roomid=14&topicid=67151 (Flangering effect with noise waveform)

--------------------------------------------------------------------------------
TODO:
- ringmod test
- sync test
- pulse width test
- envelope test
- detailed noise LFSR test
