check SID type by various methods:

- check mixed waveform $30 (from "mathematica")
- check delay of the oscillator (using waveform $20)
