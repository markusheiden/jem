- use second SID at $de00 
- you should hear alternating high pitch beep on the left (first SID) and lower
  pitched beep on the right (second SID)
