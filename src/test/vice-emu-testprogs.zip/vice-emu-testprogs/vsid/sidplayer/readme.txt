
this directory contains player code for compute gazette sidplayer files, and
some testcases associated with it.

--------------------------------------------------------------------------------
testcases:

Scroll_Machine_tune01.mus - original sidplayer data
scrollmachine.prg         - RUNable program
scrollmachine.sid         - regular PSID file (contains player code)
scrollmachine-mus.sid     - contains only the sidplayer data

I_cant_Help_Falling_in_Love.mus - original sidplayer data
I_cant_Help_Falling_in_Love.str - original sidplayer data (second SID)
fallinginlove.prg               - RUNable program (second SID at $d500 required)
fallinginlove.sid               - regular PSID file (contains player code)
