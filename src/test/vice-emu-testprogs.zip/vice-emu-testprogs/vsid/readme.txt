this directory contains testcases for SID players (in particular VSID, which
comes with VICE).

--------------------------------------------------------------------------------

tunes - "real world" test cases, from HVSC

sidplayer - compute sidplayer, tunes and tests and player code

environment - artificial tests for checking the environment tunes run in

--------------------------------------------------------------------------------

info/references:

http://www.hvsc.de/download/C64Music/DOCUMENTS/SID_file_format.txt

http://sidplayer.org/ (compute sidplayer)