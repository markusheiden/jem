The programs in this directory are meant to quickly determine if
a GEO-RAM is inserted and what size it is.

Use georam64.prg on a c64 or c128 in c64 mode.

Use georam128.prg on a c128.

Use georam20.prg on a vic20 with a georam inserted by means of
the MasC=erade adapter, the program needs to be loaded with ,8
not ,8,1, the code is position independent and should work on
any vic20 memory configuration.
