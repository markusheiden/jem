
This directory contains templates for test programs, which are also used for
self-test of the testbench.

--------------------------------------------------------------------------------

TODO:
    - make screenshots from all tests too
    - CBM2 tests could maybe use an ML copy loop instead of the basic stub :)
